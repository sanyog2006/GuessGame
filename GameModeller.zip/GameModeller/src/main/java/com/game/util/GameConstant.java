package com.game.util;

public class GameConstant {
	public static final String CONSOLE = "CONSOLE";
	public static final String READY = "READY";
	public static final String QUIT = "QUIT";
	public static final String YES = "YES";
	public static final String HIGHER = "HIGHER";
	public static final String LOWER = "LOWER";
	public static final String MOCK = "MOCK";
}

