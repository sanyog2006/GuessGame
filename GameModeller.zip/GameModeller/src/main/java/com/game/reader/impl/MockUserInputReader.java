package com.game.reader.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.game.reader.UserInputReader;

/*
 * This file contains code to read user input from a file 
 * This will be used for unit testing when user will not be entering his options on command prompt
 */
public class MockUserInputReader extends UserInputReader {
	private BufferedReader buffereader = null;

	public MockUserInputReader() {
		try {
			ClassLoader classLoader = getClass().getClassLoader();
			File file = new File(classLoader.getResource("Test.txt").getFile());
			buffereader = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String read() {
		String fileInput = null;
		try {

			fileInput = buffereader.readLine();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fileInput;
	}

	@Override
	public void close() {
		if (buffereader != null) {
			try {
				buffereader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
