package com.game.reader;

import com.game.reader.impl.ConsoleUserInputReader;
import com.game.reader.impl.MockUserInputReader;
import com.game.util.GameConstant;
/*
 * This is abstract class which gives us facility to take input from any kind of source 
 * As of now I have considered taking input from console and Text file (which I have used for my unit test ) 
 */
public abstract class UserInputReader {

	public abstract String read();

	public abstract void close();

	public static UserInputReader getReader(String readerType) {

		UserInputReader reader = null;
		if (GameConstant.CONSOLE.equalsIgnoreCase(readerType)) {
			reader = new ConsoleUserInputReader();
		} else if (GameConstant.MOCK.equalsIgnoreCase(readerType)) {
			reader = new MockUserInputReader();
		}
		return reader;
	}
}
