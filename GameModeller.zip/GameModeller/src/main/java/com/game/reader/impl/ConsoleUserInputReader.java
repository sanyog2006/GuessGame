package com.game.reader.impl;

import java.util.Scanner;

import com.game.reader.UserInputReader;

public class ConsoleUserInputReader extends UserInputReader {

	private Scanner console = new Scanner(System.in);

	public String read() {
		String userInput = null;
		try {
			userInput = console.nextLine();
		} finally {

		}
		return userInput;
	}

	public void close() {
		if (console != null) {
			console.close();
		}
	}
}
