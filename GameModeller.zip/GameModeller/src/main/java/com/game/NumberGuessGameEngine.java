package com.game;

import com.game.logger.Logger;
import com.game.reader.UserInputReader;
import com.game.util.GameConstant;
/*
 * This is the main class which reads the input from user / from other source (I assumed a file in this case for testing my unit test p)  and performs the guess work.
 */
public class NumberGuessGameEngine {

	private UserInputReader userInputReader;
	private static Logger logger;

	public NumberGuessGameEngine(String type) {
		super();
		this.userInputReader = UserInputReader.getReader(type);
		logger = Logger.getLogger(type);
	}

	private int MAX_NUMBER = 100;

	public void play() {
		logger.log("Welcome to NumberGuessingGame. Enter Ready to begin or Quit to exit");
		if (checkUserReadiness()) {
			int start = 0;
			int end = MAX_NUMBER;
			logger.log("Think a number between 1 and " + MAX_NUMBER + " .");
			sleep(1000);
			do {
				int mid = (start + end) / 2;
				logger.log("Is your number " + mid + " ?");
				String userInput = userInputReader.read();

				if (GameConstant.QUIT.equalsIgnoreCase(userInput)
						|| GameConstant.YES.equalsIgnoreCase(userInput)) {
					break;
				} else if (GameConstant.LOWER.equalsIgnoreCase(userInput)) {
					end = mid - 1;
				} else if (GameConstant.HIGHER.equalsIgnoreCase(userInput)) {
					start = mid + 1;
				} else {
					logger.log("Please enter valid input");
				}
			} while (true);

		}
		logger.log("Thanks for playing the game");

	}

	private boolean checkUserReadiness() {
		String userInput = "";
		boolean userReadyYN = false;
		do {
			userInput = userInputReader.read();
			if (GameConstant.READY.equalsIgnoreCase(userInput)) {
				userReadyYN = true;
				break;
			} else if (GameConstant.QUIT.equalsIgnoreCase(userInput)) {
				break;
			}
		} while (true);
		return userReadyYN;
	}

	// give some time to think
	private void sleep(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

		NumberGuessGameEngine numberGuessGame = new NumberGuessGameEngine(
				GameConstant.CONSOLE);
		numberGuessGame.play();
	}

}
