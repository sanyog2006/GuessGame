package com.game.logger;

import com.game.logger.impl.ConsoleLogger;
import com.game.logger.impl.MockConsoleLogger;
import com.game.util.GameConstant;

public abstract class Logger {

	public abstract void log(String msg);

	private static Logger logger;

	public static Logger getLogger(String loggerType) {

		if (GameConstant.CONSOLE.equalsIgnoreCase(loggerType)) {
			if (logger == null) {
				logger = new ConsoleLogger();
			}
		} else if (GameConstant.MOCK.equalsIgnoreCase(loggerType)) {
			if (logger == null) {
				logger = new MockConsoleLogger();
			}
		}
		return logger;

	}

}
