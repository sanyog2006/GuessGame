package com.game.logger.impl;

import com.game.logger.Logger;

public class ConsoleLogger extends Logger {

	public void log(String msg) {
		System.out.println(msg);

	}

}
