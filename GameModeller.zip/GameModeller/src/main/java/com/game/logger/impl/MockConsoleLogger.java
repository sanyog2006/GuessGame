package com.game.logger.impl;

import java.util.ArrayList;
import java.util.List;

import com.game.logger.Logger;
/*
 * This class is used to log user input during unit test when inputs are taken from a file
 */
public class MockConsoleLogger extends Logger {

	private List<String> userInputList = new ArrayList<String>();

	@Override
	public void log(String msg) {
		userInputList.add(msg);
	}

	public List<String> getUserInputList() {
		return userInputList;
	}

}
