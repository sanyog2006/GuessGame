package com.game;

import static org.junit.Assert.assertTrue;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.game.logger.Logger;
import com.game.logger.impl.MockConsoleLogger;
import com.game.util.GameConstant;

/*
 * Here I have assumed that the user has input his answers in Test.txt file
 * I am giving that input one by one to the programme 
 */
public class NumberGuessGameTest {
	private NumberGuessGameEngine numberGuessGame;

	@Before
	public void setUp() throws Exception {
		numberGuessGame = new NumberGuessGameEngine(GameConstant.MOCK);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	// Test case for user guess 75
	/*
	 * Here all the messages will get logged to the logger file if user has 75
	 * in his mind then total 5 messages will get printed in the file and last
	 * message will contain Thanks
	 */
	public void testPlay() {
		numberGuessGame.play();
		List<String> outputList = ((MockConsoleLogger) Logger
				.getLogger(GameConstant.MOCK)).getUserInputList();

		assertTrue((outputList != null && outputList.size() == 5 && outputList
				.get(4).contains("Thanks")));
	}

}
